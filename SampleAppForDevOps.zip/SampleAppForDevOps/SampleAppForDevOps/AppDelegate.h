//
//  AppDelegate.h
//  SampleAppForDevOps
//
//  Created by Kuldeep Kumpavat on 06/06/19.
//  Copyright © 2019 Kuldeep Kumpavat. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


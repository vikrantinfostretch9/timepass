//
//  main.m
//  SampleAppForDevOps
//
//  Created by Kuldeep Kumpavat on 06/06/19.
//  Copyright © 2019 Kuldeep Kumpavat. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

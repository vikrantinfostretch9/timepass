//
//  SecondViewController.m
//  SampleAppForDevOps
//
//  Created by Kuldeep Kumpavat on 06/06/19.
//  Copyright © 2019 Kuldeep Kumpavat. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
